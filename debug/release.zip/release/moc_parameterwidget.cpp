/****************************************************************************
** Meta object code from reading C++ file 'parameterwidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../code/devices/functions/parameterwidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'parameterwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_ParameterWidget_t {
    QByteArrayData data[23];
    char stringdata0[373];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ParameterWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ParameterWidget_t qt_meta_stringdata_ParameterWidget = {
    {
QT_MOC_LITERAL(0, 0, 15), // "ParameterWidget"
QT_MOC_LITERAL(1, 16, 11), // "slotFunmenu"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 10), // "QList<int>"
QT_MOC_LITERAL(4, 40, 4), // "list"
QT_MOC_LITERAL(5, 45, 27), // "on_ButtonWarnSelect_clicked"
QT_MOC_LITERAL(6, 73, 21), // "on_SaveButton_clicked"
QT_MOC_LITERAL(7, 95, 20), // "slotAlarmItemClicked"
QT_MOC_LITERAL(8, 116, 16), // "QListWidgetItem*"
QT_MOC_LITERAL(9, 133, 22), // "on_alarmUpMove_clicked"
QT_MOC_LITERAL(10, 156, 24), // "on_alarmDowmMove_clicked"
QT_MOC_LITERAL(11, 181, 22), // "on_alarmDelete_clicked"
QT_MOC_LITERAL(12, 204, 20), // "slotAlarmCellClicked"
QT_MOC_LITERAL(13, 225, 3), // "row"
QT_MOC_LITERAL(14, 229, 6), // "column"
QT_MOC_LITERAL(15, 236, 18), // "slotVarTypeChanged"
QT_MOC_LITERAL(16, 255, 5), // "index"
QT_MOC_LITERAL(17, 261, 24), // "slotSingleActiongChanged"
QT_MOC_LITERAL(18, 286, 20), // "slotOutNumberChanged"
QT_MOC_LITERAL(19, 307, 23), // "slotDisEnumNumerChanged"
QT_MOC_LITERAL(20, 331, 20), // "slotIsdisplayClicked"
QT_MOC_LITERAL(21, 352, 1), // "b"
QT_MOC_LITERAL(22, 354, 18) // "slotDisTypeChanged"

    },
    "ParameterWidget\0slotFunmenu\0\0QList<int>\0"
    "list\0on_ButtonWarnSelect_clicked\0"
    "on_SaveButton_clicked\0slotAlarmItemClicked\0"
    "QListWidgetItem*\0on_alarmUpMove_clicked\0"
    "on_alarmDowmMove_clicked\0"
    "on_alarmDelete_clicked\0slotAlarmCellClicked\0"
    "row\0column\0slotVarTypeChanged\0index\0"
    "slotSingleActiongChanged\0slotOutNumberChanged\0"
    "slotDisEnumNumerChanged\0slotIsdisplayClicked\0"
    "b\0slotDisTypeChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ParameterWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   84,    2, 0x08 /* Private */,
       5,    0,   87,    2, 0x08 /* Private */,
       6,    0,   88,    2, 0x08 /* Private */,
       7,    1,   89,    2, 0x08 /* Private */,
       9,    0,   92,    2, 0x08 /* Private */,
      10,    0,   93,    2, 0x08 /* Private */,
      11,    0,   94,    2, 0x08 /* Private */,
      12,    2,   95,    2, 0x08 /* Private */,
      15,    1,  100,    2, 0x08 /* Private */,
      17,    1,  103,    2, 0x08 /* Private */,
      18,    1,  106,    2, 0x08 /* Private */,
      19,    1,  109,    2, 0x08 /* Private */,
      20,    1,  112,    2, 0x08 /* Private */,
      22,    1,  115,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   13,   14,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void, QMetaType::Int,   16,

       0        // eod
};

void ParameterWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ParameterWidget *_t = static_cast<ParameterWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->slotFunmenu((*reinterpret_cast< QList<int>(*)>(_a[1]))); break;
        case 1: _t->on_ButtonWarnSelect_clicked(); break;
        case 2: _t->on_SaveButton_clicked(); break;
        case 3: _t->slotAlarmItemClicked((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 4: _t->on_alarmUpMove_clicked(); break;
        case 5: _t->on_alarmDowmMove_clicked(); break;
        case 6: _t->on_alarmDelete_clicked(); break;
        case 7: _t->slotAlarmCellClicked((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 8: _t->slotVarTypeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->slotSingleActiongChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->slotOutNumberChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->slotDisEnumNumerChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->slotIsdisplayClicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: _t->slotDisTypeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<int> >(); break;
            }
            break;
        }
    }
}

const QMetaObject ParameterWidget::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_ParameterWidget.data,
      qt_meta_data_ParameterWidget,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ParameterWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ParameterWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ParameterWidget.stringdata0))
        return static_cast<void*>(const_cast< ParameterWidget*>(this));
    return QDialog::qt_metacast(_clname);
}

int ParameterWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
